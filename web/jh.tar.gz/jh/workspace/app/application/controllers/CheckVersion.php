<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of checkVersion
 *
 * @author App-Dev
 */
class CheckVersion extends CI_Controller{
    
    public function getVersion()
    {
        $current_version_code = "22";							//当前版本号
		$new_version_character = "提升了相册的使用体验。";	//新版本特性
		$show_ad = "1";			//华为渠道的审核版本（也就是最新版本）审核时不显示广告     0不显示广告，用在审核阶段；1显示广告，上架成功后记得设置
		$show_ad_gap_time = "1";	//多少分钟内重复打开APP，不显示广告
		
        $out['status'] = "1";
		$out['code'] = $current_version_code;
		$out['character'] = $new_version_character;
		$out['show_ad'] = $show_ad;
		$out['show_ad_gap_time'] = $show_ad_gap_time;
		
        header("Content-type: application/json");
        $data = json_encode($out);
        if (!$data) {
            $json = new Services_JSON();
            $data = $json->encode($out);
        }
        die($data);
    }
}
